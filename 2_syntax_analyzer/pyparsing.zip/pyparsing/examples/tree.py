class BinaryTree(object):
    def __init__(self, left=None, data=None, right=None):
         self.left = left
         self.data = data
         self.right = right

def create_tree(data):
    global tree_level

    if not data:
        return data

    #print('# of lists in list:', len(data))
    if type(data) != int and len(data) != 3:
        #if len(data) > 3:
            #print(" ^ terminal node")

        return data

    if type(data) != int and len(data) == 3:
        l, d, r = data 
        if type(l) != int and type(d) != int and type(r) != int:
            print("operator:", d)
            print("Left:", len(l), ", Center:", len(d), ", Right:", len(r))
        
            if len(l) != 3 and len(r) != 3:
                print("Left:", l, ", Center:", d, ", Right:", r) 

        #if type(l) == int:
        #print("Left:", l, ", Center:", d, ", Right:", r)

    return BinaryTree(create_tree(l), d, create_tree(r))

